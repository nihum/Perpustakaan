<?php $__env->startSection('judul'); ?>
Form Peminjaman
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-pin'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box">
    <div class="box-body">
    <?php if($anggota==""): ?>
        <form id="frmPinjam" class="form-horizontal" action="<?php echo e(url('trans/peminjaman')); ?>" method="post">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="no_anggota" class="col-sm-12 control-label" style="text-align:center;">NO ANGGOTA</label>
                <div class="col-md-4"></div>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="no_anggota" name="no_anggota" >
                </div>
                <div class="col-md-4"></div>
            </div>
        </form>
    <?php else: ?>

        <form id="frmPinjam" class="form-horizontal" action="<?php echo e(url('trans/peminjaman/save')); ?>" method="post">
        <?php echo csrf_field(); ?>
            <!--input no anggota-->
            <!-- <input type="hidden" class="form-control" id="kd_anggota" name="kd_anggota" value="<?php echo e($anggota->kd_anggota); ?>"> -->
            <input type="hidden" class="form-control" id="no_anggota" name="no_anggota" value="<?php echo e($anggota->no_anggota); ?>">
            <input type="hidden" name="nama" value="<?php echo e($anggota->nama); ?>">  
            <div class="box-header">
                <h3 class="box-title">Data Peminjam</h3>
                <br/><br/>
                <b><?php echo e($anggota->nama); ?> <?php echo e($anggota->no_anggota); ?></b><br/>
                <?php echo e($anggota->alamat." ".$anggota->kota); ?><br/>
                Email : <?php echo e($anggota->email); ?>

            </div>
            <div class="box-header">
                <h3 class="box-title">Detail Peminjaman</h3>
                <div class="box-tools">
                <button type="button" class="btn btn-primary btn-flat" data-toggle="modal" data-target="#m-buku">Tambahkan Buku</button>
                </div>
            </div>
            <!-- Tabel List Buku Yang Dipinjam -->
            <table class="table table-hover" style="margin-top: 15px">
                <tbody id="lsBuku">
                    <tr style="background: #ccc;">
                        <th>#</th>
                        <th>No Induk Buku</th>
                        <th>Judul</th>
                        <th>Action</th>
                    </tr>
                </tbody>
            </table>
            <div class="box-footer">
                <button type="submit" class="btn btn-success btn-flat">SIMPAN</button>
                <a href="<?php echo e(url('trans/peminjaman')); ?>"><button type="button" class="btn btn-warning btn-flat">BATAL</button></a>
            </div>
        </form>
    <?php endif; ?>
    </div>
</div>

<?php if($buku!=""): ?>
<!--List Data Buku -->
<div class="modal modal-default fade" id="m-buku">
    <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Data Buku</h4>
        </div>
        <div class="modal-body">
            <table id="data" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>No Induk</th>
                            <th>Judul</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>

                    <!--Menampilkan Data Anggota -->
                        <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsBuku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($rsBuku->kd_koleksi); ?></td>
                                <td><?php echo e($rsBuku->no_induk_buku); ?></td>
                                <td><?php echo e($rsBuku->judul); ?></td>
                                <td>
                                    <button class="btn btn-primary btn-xs btn-flat" onclick="add_buku('<?php echo e($rsBuku->no_induk_buku); ?>','<?php echo e($rsBuku->judul); ?>')" data-dismiss="modal">PILIH</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
            </table>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal">Close</button>
        </div>
    </div>
    <!-- /.modal-content -->

    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>