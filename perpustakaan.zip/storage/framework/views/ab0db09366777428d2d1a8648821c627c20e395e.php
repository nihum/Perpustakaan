<?php $__env->startSection('judul'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-dash'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subjudul'); ?>
The future is not where my dream is
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-thumbs-o-up"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Bookmarks</span>
              <span class="info-box-number"><?php echo e($jumlah); ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 70%"></div>
              </div>
                  <span class="progress-description">
                    70% Increase in 30 Days
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>