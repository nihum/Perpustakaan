<?php $__env->startSection('judul'); ?>
Form Pengarang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form id="frmPengarang" class="form-horizontal" action="<?php echo e(url('pengarang/save')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="fForm col-md-8">
            <div class="box">
                <!-- Bidodata Anggota -->
                <div class="box-header with-border">
                    <h3 class="box-title">Data Pengarang</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="pengarang" class="col-sm-2 control-label">Pengarang</label>
                        <div class="col-sm-10">
                            <input type="hidden" class="form-control" id="kd_pengarang" name="kd_pengarang" value="<?php echo e($pengarang['kd_pengarang']); ?>">
                            <input type="text" class="form-control" id="pengarang" placeholder="Nama Pengarang" name="pengarang" value="<?php echo e($pengarang['nama_pengarang']); ?>">
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary pull-right">SAVE</button>
                </div>                   
            </div>
        </div>       
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>