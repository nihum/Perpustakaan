<?php $__env->startSection('judul'); ?>
Form Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-buku'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(count($errors) > 0 ): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form id="frmbuku" class="form-horizontal" action="<?php echo e(url('buku/save')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="fFoto col-md-3">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Foto</h3>
                </div>
                <div class="box-body">
                    <?php if($buku['cover']): ?>
                        <img id="avatar" src="<?php echo e(asset('img/'.$buku['cover'])); ?>" style="width:100%;border: 2px solid #ccc;">
                    <?php else: ?>
                        <img id="avatar" src="<?php echo e(asset('img/no-photo.jpg')); ?>" style="width:100%;border: 2px solid #ccc;">
                    <?php endif; ?>
                    <input id="file" type="file" name="foto" style="display: none">
                    <input type="hidden" name="old_foto" value="<?php echo e($buku['cover']); ?>">

                </div>
            </div>

        </div>
        <div class="fForm col-md-9">
            <div class="box">
                <!--frm buku -->
                <div class="box-header with-border">
                    <h3 class="box-title">Data Buku</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="nama" class="col-sm-2 control-label">Judul buku</label>
                        <div class="col-sm-10">
                            <input type="hidden" class="form-control" name="kd_buku" value="<?php echo e($buku['kd_buku']); ?>">
                            <input type="text" class="form-control" id="judul" placeholder="judul buku" name="judul" value="<?php echo e($buku['judul']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="pengarang" class="col-sm-2 control-label"><a href="<?php echo e(url('/pengarang')); ?>" target="_BLANK">Pengarang <i class="fa fa-pencil"></i></a></label>
                        <div class="col-sm-10">
                                <select class="form-control" name="pengarang" value="<?php echo e($buku['kd_pengarang']); ?>">
                                    <option  value="" >- Pilih Pengarang -</option>
                                    <?php $__currentLoopData = $pengarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsPeng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($buku['kd_pengarang']==$rsPeng['kd_pengarang'] ? 'selected' : ""); ?> value="<?php echo e($rsPeng['kd_pengarang']); ?>"><?php echo e($rsPeng['nama_pengarang']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                             
                                </select>
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="penerbit" class="col-sm-2 control-label"><a href="<?php echo e(url('/penerbit')); ?>" target="_BLANK">Penerbit <i class="fa fa-print"></i></a></label>
                        <div class="col-sm-10">
                            <select class="form-control" name="penerbit" value="<?php echo e($buku['kd_penerbit']); ?>">
                                <option  value="" >- Pilih Penerbit -</option>
                                <?php $__currentLoopData = $penerbit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsPen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($buku['kd_penerbit']==$rsPen['kd_penerbit'] ? 'selected' : ""); ?> value="<?php echo e($rsPen['kd_penerbit']); ?>"><?php echo e($rsPen['nama_penerbit']); ?></option>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                             
                            </select>
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="tempat" class="col-sm-2 control-label">Tempat / Tahun Terbit</label>
                        <div class="col-sm-5">
                            <input type="text" class="form-control" id="tempat" placeholder="Tempat Terbit" name="tempat_terbit" value="<?php echo e($buku['tempat_terbit']); ?>">
                        </div>
                        <div class="col-sm-5">
                            <input type="text" class="form-control" id="tahun" placeholder="Tahun Terbit" name="tahun_terbit" value="<?php echo e($buku['tahun_terbit']); ?>">
                        </div>
                    </div>
                   <div class="form-group">
                        <label for="kategori" class="col-sm-2 control-label"> <a href="<?php echo e(url('/kategori')); ?>" target="_BLANK">Kategori <i class="fa fa-tag"></i> </a></label>
                        <div class="col-sm-10">
                            <select class="form-control" name="kategori" value="<?php echo e($buku['kd_kategori']); ?>">
                                <option value="">- Pilih Kategori -</option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsKat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($buku['kd_kategori']==$rsKat['kd_kategori'] ? 'selected' : ""); ?> value="<?php echo e($rsKat['kd_kategori']); ?>"><?php echo e($rsKat['nama_kategori']); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                             
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="halaman" class="col-sm-2 control-label">Halaman</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="halaman" placeholder="Halaman" name="halaman" value="<?php echo e($buku['halaman']); ?>">
                        </div>
                    </div>                        
                    <div class="form-group">
                        <label for="edisi" class="col-sm-2 control-label">Edisi</label>
                        <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Edisi" name="edisi" value="<?php echo e($buku['edisi']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="isbn" class="col-sm-2 control-label">ISBN</label>
                        <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="ISBN" name="isbn" value="<?php echo e($buku['ISBN']); ?>">
                        </div>
                    </div> 
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary pull-right">
                    <?php if($buku['kd_buku']==""): ?>
                    SAVE
                    <?php else: ?>
                    UPDATE
                    <?php endif; ?></button>
                </div>                   
            </div>
        </div>       
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>