<?php $__env->startSection('judul'); ?>
Riwayat Peminjaman Buku  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-ang'); ?>
active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="box">
    <div class="box-header">

    </div>
    <div class="box-body">
        <table id="data" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Nomor Pinjam</th>
                    <th>Judul</th>
                    <th>Tanggal Peminjaman Buku</th>
                </tr>
            </thead>
            <tbody>
                <!-- Menampilkan Data Pinjam -->
                <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsHis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rsHis->nama); ?></td>
                    <td><?php echo e($rsHis->no_pinjam); ?></td>   
                    <td><?php echo e($rsHis->judul); ?></td>
                    <td><?php echo e($rsHis->tgl_pinjam); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>