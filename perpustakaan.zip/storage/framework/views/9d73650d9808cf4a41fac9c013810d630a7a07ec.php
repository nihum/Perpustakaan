<?php $__env->startSection('judul'); ?>
Form Pengembalian
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-pin'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?> -->

<div class="box">
    <div class="box-body">
    <?php if($pinjam==""): ?>
        <form id="frmKembali" class="form-horizontal" action="<?php echo e(url('trans/pengembalian')); ?>" method="post">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="no_pinjam" class="col-sm-12 control-label" style="text-align:center;">NO PINJAM</label>
                <div class="col-md-4"></div>
                <div class="col-sm-4">
                    <input type="text" class="form-control" id="no_pinjam" name="no_pinjam" >
                </div>
                <div class="col-md-4"></div>
            </div>
        </form>
    <?php else: ?>

        <form id="frmPinjam" class="form-horizontal" action="<?php echo e(url('trans/pengembalian/save')); ?>" method="post">
        <?php echo csrf_field(); ?>
            <!--input no pinjam-->
            <input type="hidden" class="form-control" id="no_pinjam" name="no_pinjam" value="<?php echo e($pinjam[0]->no_pinjam); ?>"> 
            <div class="box-header">
                <h3 class="box-title">#<?php echo e($pinjam[0]->no_pinjam); ?></h3>
                <br/><br/>
                No Anggota : <strong><?php echo e($pinjam[0]->no_anggota); ?></strong><br/>
                Nama       : <?php echo e($pinjam[0]->nama); ?>

            </div>

            <div class="box-header">
                <h3 class="box-title">Detail Peminjaman</h3>
            </div>
            <!-- Tabel List Buku Yang Dipinjam -->
            <table class="table table-hover" style="margin-top: 15px">
                <tbody id="lsBuku">
                    <tr style="background: #ccc;">
                        <th width="15%">No Induk Buku</th>
                        <th>Judul</th>
                        <th width="5%">Telat</th>
                        <th width="5%">Denda</th>
                    </tr>
                    <?php $__currentLoopData = $pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsPinjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th width="10%">
                        <?php echo e($rsPinjam->no_induk_buku); ?>

                        <input type="hidden" name="no_induk[]" value="<?php echo e($rsPinjam->no_induk_buku); ?>">
                        </th>
                        <th><?php echo e($rsPinjam->judul); ?></th>
                        <th width="8%">
                        <!--menghitung selisih hari -->
                        <?php
                            $kembali = new DateTime
                            ($rsPinjam->tgl_kembali);
                            $hariini = new DateTime;
                            $selisih =$kembali->diff($hariini);
                            $lamadenda = 0;
                            if($hariini>$kembali){
                                $lamadenda = $selisih->d;
                            }
                            echo $lamadenda;
                        ?>
                        Hari
                        </th>
                        <th width="8%">
                            <?php echo e($lamadenda * 2000); ?>

                            <input type="hidden" name="denda" value="<?php echo e($selisih->d * 2000); ?>">
                        </th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="box-footer">
                <button type="submit" class="btn btn-success btn-flat">SIMPAN</button>
                <a href="<?php echo e(url('trans/pengembalian')); ?>"><button type="button" class="btn btn-warning btn-flat">BATAL</button></a>
            </div>
        </form>
    <?php endif; ?>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>