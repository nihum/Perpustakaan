<?php $__env->startSection('judul'); ?>
Data Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="box">
        <div class="box-header">
        <a href="<?php echo e(url('buku/add')); ?>"><button class="btn btn-green btn-flat" ><i class="fa fa-book"></i> Tambah</button></a>
        </div>
    <!-- /.box-header -->
        <div class="box-body">
            <table id="data" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Judul</th>
                        <th>Pengarang</th>
                        <th>Penerbit</th>
                        <th>Kategori</th>
                        <th>Halaman</th>
                        <th>Edisi</th>
                        <th>ISBN</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <!-- menampilkan data -->
                <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsBuku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($rsBuku->kd_buku); ?></td>
                        <td><?php echo e($rsBuku->judul); ?></td>
                        <!--ini menggunakan Function di MGlobal-->
                        <td><?php echo e(App\MGlobal::Get_Pengarang($rsBuku->kd_pengarang)); ?></td>
                        <td><?php echo e(App\MGlobal::Get_Penerbit($rsBuku->kd_penerbit)." / ".$rsBuku->tempat_terbit."/".$rsBuku->tahun_terbit); ?></td>
                        <td><?php echo e(App\MGlobal::Get_Kategori($rsBuku->kd_kategori)); ?></td>

                        <!--ini jika menggunakan Query builder
                        <td><?php echo e($rsBuku->nama_pengarang); ?></td>
                        -->
                        <!--ini jika menggunakan Query builder
                        <td><?php echo e($rsBuku->nama_penerbit .'/'.$rsBuku->tempat_terbit. '/' .$rsBuku->tahun_terbit); ?></td>
                        -->
                        <!--ini jika menggunakan Query builder
                        <td><?php echo e($rsBuku->nama_kategori); ?></td>
                        -->
                        <td><?php echo e($rsBuku->halaman); ?></td>
                        <td><?php echo e($rsBuku->edisi); ?></td>
                        <td><?php echo e($rsBuku->ISBN); ?></td>
                        <td>
                        <a href="<?php echo e(url('buku/edit' , $rsBuku->kd_buku)); ?>"><button class="btn bg-yellow btn-flat" ><i class="fa fa-pencil"></i></button></a>
                        <a href="<?php echo e(url('buku/delete' , $rsBuku->kd_buku)); ?>"><button class="btn btn-danger btn-flat" ><i class="fa fa-trash"></i></button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>