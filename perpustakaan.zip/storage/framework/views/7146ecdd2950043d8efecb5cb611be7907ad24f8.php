<style>
    table{
        width:100%;
    }
    table td{
        text-align:center;
    }
</style>

<?php
    $i = 1;
    $count = count($anggota);
?>


<table>
<?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsAng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($i%6==1): ?>
    <tr>
<?php endif; ?>
        <td width="20%"><img src="data:image/png;base64,<?php echo e(base64_encode(QrCode::format('png')->size(150)->color(41,41,97)->generate($rsAng->no_anggota) )); ?>">
        <p><?php echo e($rsAng->no_anggota); ?></p>
        </td>
<?php if(($i%6)==0 || $i==$count ): ?>
    </tr>
<?php endif; ?>

<?php
$i++;
?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
