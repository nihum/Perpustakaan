<?php $__env->startSection('judul'); ?>
Data user
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <div class="box">
        <div class="box-header">
        <a href="<?php echo e(url('user/add')); ?>" target="_BLANK"><button class="btn btn-green btn-flat" ><i class="fa fa-user"></i> Tambah</button></a>
        </div>
    <!-- /.box-header -->
        <div class="box-body">
            <table id="data" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Telepon</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <!-- menampilkan data -->
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($rsUser->id); ?></td>
                        <td><?php echo e($rsUser->name); ?></td>
                        <td><?php echo e($rsUser->alamat); ?></td>
                        <td><?php echo e($rsUser->telp); ?></td>
                        <td><?php echo e($rsUser->email); ?></td>
                        <td>
                        <a href="<?php echo e(url('user/edit', $rsUser->id)); ?>"><button class="btn bg-yellow btn-flat" ><i class="fa fa-pencil"></i></button></a>
                        <a href="/user/delete/<?php echo e($rsUser->id); ?>"><button class="btn btn-danger btn-flat" ><i class="fa fa-trash"></i></button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>